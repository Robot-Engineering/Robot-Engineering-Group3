import turtle
class DrawRect:
    def __init__(self):
        self.__a=a
        self.__b=b
    def draw(self):
        turtle.goto(a,0)
        turtle.left(90)
        turtle.forward(b)
        turtle.left(90)
        turtle.forward(a)
        turtle.left(90)
        turtle.forward(b)
a=float(input("请输入矩形的长:"))
b=float(input("请输入矩形的宽:"))
t=DrawRect()
t.draw()
