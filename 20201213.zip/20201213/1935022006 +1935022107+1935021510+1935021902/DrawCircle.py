import turtle
class Drawcircle:
    def __init__(self):
        self.__r=r
        self.__x1=x1
        self.__y1=y1
    def draw(self):
        turtle.up()
        turtle.goto(x1,y1-r)
        turtle.down()
        turtle.circle(r)
r=float(input("请输入半径:"))
x1=float(input("请输入圆心横坐标:"))
y1=float(input("请输入圆心纵坐标:"))
t=Drawcircle()
t.draw()
