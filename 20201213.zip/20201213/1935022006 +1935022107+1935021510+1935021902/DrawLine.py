import turtle
class Drawline:
    def __init__(self):
        self.__x1=x1
        self.__y1=y1
        self.__x2=x2
        self.__y2=y2
    def draw(self):
        turtle.up()
        turtle.goto(x1,y1)
        turtle.down()
        turtle.goto(x2,y2)
x1=float(input("请输入第一点横坐标:"))
y1=float(input("请输入第一点纵坐标:"))
x2=float(input("请输入第二点横坐标:"))
y2=float(input("请输入第二点纵坐标:"))
t=Drawline()
t.draw()
